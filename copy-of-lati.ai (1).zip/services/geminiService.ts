
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Recipe, UserProfile } from "../types";

// Always initialize with direct process.env.API_KEY reference
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getLanguageName = (code?: string) => {
  switch(code) {
    case 'en': return 'English';
    case 'fr': return 'French';
    case 'es': return 'Spanish';
    default: return 'Italian';
  }
};

export const generateRecipe = async (
  prompt: string,
  userProfile: UserProfile,
  antiWasteIngredients: string[] = []
): Promise<Recipe> => {
  const model = 'gemini-3-flash-preview';
  const language = getLanguageName(userProfile.language);
  
  const systemInstruction = `You are a world-class culinary AI assistant. 
  Create a highly detailed, personalized recipe based on user goals: ${userProfile.goals}, 
  cooking level: ${userProfile.cookingLevel}, and tools: ${userProfile.tools.join(', ')}.
  Avoid these allergies: ${userProfile.allergies.join(', ')}.
  MANDATORY: All text content (title, description, instructions, ingredient names) MUST be in ${language}.
  Format the output strictly as JSON.
  If ingredients are provided for anti-waste, prioritize them.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt + (antiWasteIngredients.length ? `. Use these: ${antiWasteIngredients.join(', ')}` : ''),
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          nutrition: {
            type: Type.OBJECT,
            properties: {
              calories: { type: Type.NUMBER },
              protein: { type: Type.NUMBER },
              carbs: { type: Type.NUMBER },
              fats: { type: Type.NUMBER },
              fiber: { type: Type.NUMBER }
            },
            required: ['calories', 'protein', 'carbs', 'fats']
          },
          ingredients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                amount: { type: Type.NUMBER },
                unit: { type: Type.STRING },
                category: { type: Type.STRING }
              }
            }
          },
          steps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                instruction: { type: Type.STRING },
                timer: { type: Type.NUMBER }
              }
            }
          },
          prepTime: { type: Type.NUMBER },
          difficulty: { type: Type.STRING },
          tags: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ['title', 'description', 'ingredients', 'steps', 'nutrition']
      }
    }
  });

  const recipe: Recipe = JSON.parse(response.text || '{}');
  return recipe;
};

export const generateWeeklyPlan = async (userProfile: UserProfile): Promise<any> => {
  const model = 'gemini-3-flash-preview';
  const language = getLanguageName(userProfile.language);
  
  const systemInstruction = `Generate a personalized weekly 7-day meal plan (3 meals per day) strictly following the user's objective: ${userProfile.goals}.
  Language: ${language}.
  Return a JSON object where keys are day abbreviations (e.g., 'Lun', 'Mar', etc., adjusted for the requested language).
  Each day should have 'breakfast', 'lunch', 'dinner' (titles only) and 'totalKcal'.
  The diet must be scientifically accurate for ${userProfile.goals}.`;

  const response = await ai.models.generateContent({
    model,
    contents: `Genera un piano settimanale per l'obiettivo: ${userProfile.goals}.`,
    config: {
      systemInstruction,
      responseMimeType: "application/json"
    }
  });

  return JSON.parse(response.text || '{}');
};

export const generateRecipeImage = async (recipeTitle: string): Promise<string | undefined> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `High-end commercial food photography of ${recipeTitle}. Minimalist plating, professional lighting, 8k resolution, cinematic atmosphere, appetizing.` }]
      },
      config: {
        imageConfig: { aspectRatio: "16:9" }
      }
    });

    const imagePart = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
    if (imagePart?.inlineData) {
      return `data:image/png;base64,${imagePart.inlineData.data}`;
    }
  } catch (err) {
    console.error("Image generation failed", err);
  }
  return undefined;
};

export const analyzeIngredientsFromImage = async (base64Data: string, languageCode?: string): Promise<string[]> => {
  try {
    const language = getLanguageName(languageCode);
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Data,
            },
          },
          { text: `Analyze this image and identify all food ingredients or grocery products visible. Return ONLY a JSON array of strings with the ingredient names in ${language}. Be precise and concise.` },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });

    const ingredients: string[] = JSON.parse(response.text || '[]');
    return Array.isArray(ingredients) ? ingredients : [];
  } catch (err) {
    console.error("Vision analysis failed", err);
    return [];
  }
};
