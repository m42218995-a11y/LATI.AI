
export interface UserProfile {
  name: string;
  goals: 'weight-loss' | 'muscle-gain' | 'keto' | 'balanced';
  allergies: string[];
  cookingLevel: 'beginner' | 'intermediate' | 'expert';
  tools: string[];
  budget: 'low' | 'medium' | 'premium';
  timePerMeal: number; // in minutes
  language?: 'it' | 'en' | 'fr' | 'es';
}

export interface Ingredient {
  name: string;
  amount: number;
  unit: string;
  category: string;
}

export interface Nutrition {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber: number;
}

export interface RecipeStep {
  instruction: string;
  timer?: number; // minutes
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  image?: string;
  nutrition: Nutrition;
  ingredients: Ingredient[];
  steps: RecipeStep[];
  prepTime: number;
  difficulty: string;
  tags: string[];
  versions?: {
    fast?: string;
    budget?: string;
    gourmet?: string;
  };
}

export interface MealPlan {
  day: string;
  meals: {
    breakfast: Recipe;
    lunch: Recipe;
    dinner: Recipe;
  };
}
