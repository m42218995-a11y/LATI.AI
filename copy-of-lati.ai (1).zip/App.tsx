
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { UserProfile } from './types';
import Dashboard from './components/Dashboard';
import RecipeGenerator from './components/RecipeGenerator';
import MealPlanner from './components/MealPlanner';
import ProfileSettings from './components/ProfileSettings';
import ShoppingList from './components/ShoppingList';
import Auth from './components/Auth';
import { 
  HomeIcon, 
  SparklesIcon, 
  CalendarIcon, 
  ShoppingBagIcon, 
  UserCircleIcon
} from './components/Icons';

// Simple Translation Map
export const t = {
  it: {
    dashboard: "Aura",
    chef: "Chef",
    rituals: "Rituali",
    archive: "Archivio",
    identity: "Identità",
    session: "Termina Sessione",
    orchestration: "Orchestrazione Intelligente",
    language: "Lingua"
  },
  en: {
    dashboard: "Aura",
    chef: "Chef",
    rituals: "Rituals",
    archive: "Archive",
    identity: "Identity",
    session: "End Session",
    orchestration: "Intelligence Orchestration",
    language: "Language"
  },
  fr: {
    dashboard: "Aura",
    chef: "Chef",
    rituals: "Rituels",
    archive: "Archives",
    identity: "Identité",
    session: "Quitter Session",
    orchestration: "Orchestration Intelligente",
    language: "Langue"
  },
  es: {
    dashboard: "Aura",
    chef: "Chef",
    rituals: "Rituales",
    archive: "Archivo",
    identity: "Identidad",
    session: "Cerrar Sesión",
    orchestration: "Orquestación Inteligente",
    language: "Idioma"
  }
};

const App: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('lati_user_profile');
    return saved ? JSON.parse(saved) : null;
  });

  const [pantry, setPantry] = useState<string[]>(() => {
    const saved = localStorage.getItem('lati_pantry');
    return saved ? JSON.parse(saved) : ["Salmone", "Avocado", "Riso Basmati", "Zenzero", "Limone"];
  });

  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem('lati_logged_in') === 'true';
  });

  const [lang, setLang] = useState<'it' | 'en' | 'fr' | 'es'>(() => {
    return (profile?.language as any) || 'it';
  });

  useEffect(() => {
    if (profile) {
      localStorage.setItem('lati_user_profile', JSON.stringify({ ...profile, language: lang }));
    }
  }, [profile, lang]);

  useEffect(() => {
    localStorage.setItem('lati_pantry', JSON.stringify(pantry));
  }, [pantry]);

  const handleAuthComplete = (newProfile: UserProfile) => {
    setProfile(newProfile);
    if (newProfile.language) setLang(newProfile.language);
    setIsLoggedIn(true);
    localStorage.setItem('lati_logged_in', 'true');
    localStorage.setItem('lati_user_profile', JSON.stringify(newProfile));
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('lati_logged_in');
  };

  if (!isLoggedIn || !profile) {
    return <Auth onComplete={handleAuthComplete} />;
  }

  const currentT = t[lang];

  return (
    <Router>
      <div className="flex h-screen overflow-hidden bg-black text-white/90 font-sans selection:bg-gold/20">
        {/* Sidebar */}
        <aside className="w-20 md:w-64 glass border-r border-white/5 flex flex-col py-12 z-20 overflow-y-auto overflow-x-hidden scrollbar-thin scrollbar-thumb-gold/10">
          <div className="mb-20 text-center flex-shrink-0 px-6">
            <h1 className="text-2xl font-display font-bold tracking-[0.4em] text-gold text-glow hidden md:block">LATI.AI</h1>
            <p className="text-[7px] text-white/20 uppercase tracking-mega-widest mt-3 hidden md:block">{currentT.orchestration}</p>
            <div className="w-10 h-10 bg-gold/5 border border-gold/20 rounded-full md:hidden mx-auto flex items-center justify-center font-bold text-gold text-xs">L</div>
          </div>
          
          <nav className="flex-1 space-y-4 w-full px-6 mb-12">
            <NavItem to="/" icon={<HomeIcon />} label={currentT.dashboard} />
            <NavItem to="/generate" icon={<SparklesIcon />} label={currentT.chef} />
            <NavItem to="/planner" icon={<CalendarIcon />} label={currentT.rituals} />
            <NavItem to="/shopping" icon={<ShoppingBagIcon />} label={currentT.archive} />
            <NavItem to="/profile" icon={<UserCircleIcon />} label={currentT.identity} />
          </nav>

          <div className="mt-auto px-6 w-full space-y-8 flex-shrink-0">
            {/* Language Switcher */}
            <div className="space-y-3">
              <p className="text-[8px] text-gold/30 uppercase tracking-mega-widest text-center">{currentT.language}</p>
              <div className="flex justify-center gap-2">
                {['it', 'en', 'fr', 'es'].map((l) => (
                  <button
                    key={l}
                    onClick={() => setLang(l as any)}
                    className={`w-8 h-8 rounded-full border text-[9px] font-black uppercase transition-all flex items-center justify-center ${
                      lang === l ? 'bg-gold border-gold text-black shadow-lg shadow-gold/20' : 'border-white/5 text-white/20 hover:border-gold/30'
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={handleLogout}
              className="w-full py-5 bg-white/[0.02] hover:bg-gold/5 rounded-2xl text-[8px] font-black transition-all text-white/20 hover:text-gold uppercase tracking-ultra-widest border border-white/5 hover:border-gold/20"
            >
              {currentT.session}
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto relative scroll-smooth bg-black">
          <div className="fixed top-0 right-0 w-[1000px] h-[1000px] bg-gold/[0.03] blur-[220px] rounded-full -z-10 pointer-events-none opacity-50"></div>
          <div className="fixed bottom-0 left-0 w-[600px] h-[600px] bg-gold/[0.03] blur-[180px] rounded-full -z-10 pointer-events-none opacity-50"></div>
          
          <div className="max-w-6xl mx-auto px-12 py-16 min-h-full">
            <Routes>
              <Route path="/" element={<Dashboard profile={profile} lang={lang} />} />
              <Route path="/generate" element={<RecipeGenerator profile={profile} globalPantry={pantry} lang={lang} />} />
              <Route path="/planner" element={<MealPlanner profile={profile} lang={lang} />} />
              <Route path="/shopping" element={<ShoppingList pantry={pantry} setPantry={setPantry} lang={lang} />} />
              <Route path="/profile" element={<ProfileSettings profile={profile} setProfile={setProfile} lang={lang} />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </div>
        </main>
      </div>
    </Router>
  );
};

const NavItem: React.FC<{ to: string, icon: React.ReactNode, label: string }> = ({ to, icon, label }) => (
  <NavLink 
    to={to} 
    className={({ isActive }) => 
      `flex items-center gap-6 px-6 py-5 rounded-2xl transition-all duration-500 border border-transparent ${
        isActive ? 'bg-gold/5 text-gold border-gold/10 shadow-[0_15px_40px_rgba(212,175,55,0.08)]' : 'text-white/20 hover:text-white/70 hover:bg-white/[0.02]'
      }`
    }
  >
    <div className="flex-shrink-0 transition-all duration-500 opacity-80">{icon}</div>
    <span className="hidden md:block font-bold text-[9px] tracking-mega-widest uppercase">{label}</span>
  </NavLink>
);

export default App;
