
import React, { useState, useRef } from 'react';
import { LoaderIcon, SparklesIcon } from './Icons';
import { analyzeIngredientsFromImage } from '../services/geminiService';

const shoppingT = {
  it: { title: "Inventario d'Archivio", sub: "Archivio Asset", registry: "Registro Manuale", declare: "Dichiara asset...", register: "Registra in Archivio", vision: "AI Vision Scan", registered: "Asset Registrati", units: "Unità", scan: "Scansiona Ingredienti", abort: "Interrompi", empty: "Nessun asset rilevato nella matrice attuale.", purge: "Svuota Database" },
  en: { title: "Archive Inventory", sub: "Asset Archive", registry: "Manual Registry", declare: "Declare asset...", register: "Register into Archive", vision: "AI Vision Scan", registered: "Registered Assets", units: "Units", scan: "Scan Ingredients", abort: "Abort", empty: "No assets detected in current matrix.", purge: "Purge Database" },
  fr: { title: "Inventaire d'Archives", sub: "Archives des Actifs", registry: "Registre Manuel", declare: "Déclarer l'actif...", register: "Enregistrer dans l'Archive", vision: "AI Vision Scan", registered: "Actifs Enregistrés", units: "Unités", scan: "Scanner Ingrédients", abort: "Abandonner", empty: "Aucun actif détecté dans la matrice actuelle.", purge: "Purger la Base" },
  es: { title: "Inventario de Archivo", sub: "Archivo de Activos", registry: "Registro Manual", declare: "Declarar activo...", register: "Registrar en Archivo", vision: "AI Vision Scan", registered: "Activos Registrados", units: "Unidades", scan: "Escanear Ingredientes", abort: "Abortar", empty: "No se detectaron activos en la matriz actual.", purge: "Purgar Base de Datos" }
};

const ShoppingList: React.FC<{ pantry: string[], setPantry: (items: string[]) => void, lang: string }> = ({ pantry, setPantry, lang }) => {
  const currentT = shoppingT[lang as keyof typeof shoppingT] || shoppingT.en;
  const [newItem, setNewItem] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const addItem = (item: string) => {
    const trimmed = item.trim();
    if (trimmed && !pantry.includes(trimmed)) {
      setPantry([...pantry, trimmed]);
      setNewItem('');
    }
  };

  const removeItem = (item: string) => {
    setPantry(pantry.filter(i => i !== item));
  };

  const startCamera = async () => {
    setCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      console.error("Camera access failed", err);
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
    }
    setCameraActive(false);
  };

  const captureAndAnalyze = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    setIsAnalyzing(true);
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const base64Image = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
      const detectedIngredients = await analyzeIngredientsFromImage(base64Image, lang);
      if (detectedIngredients.length > 0) {
        const uniqueNew = detectedIngredients.filter(ing => !pantry.some(p => p.toLowerCase() === ing.toLowerCase()));
        if (uniqueNew.length > 0) {
          setPantry([...pantry, ...uniqueNew]);
        }
      }
    }
    setIsAnalyzing(false);
    stopCamera();
  };

  return (
    <div className="max-w-5xl mx-auto space-y-20 animate-in fade-in duration-1000">
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-end border-b border-white/5 pb-12 gap-12">
        <div className="space-y-5">
          <p className="text-[10px] font-black text-gold uppercase tracking-mega-widest opacity-40">{currentT.sub}</p>
          <h1 className="text-7xl font-display font-bold leading-tight tracking-tight text-white">{currentT.title}</h1>
        </div>
        <div className="text-right glass px-12 py-8 rounded-[40px] border-white/5 bg-white/[0.01]">
          <p className="text-[9px] text-white/20 uppercase font-black tracking-mega-widest mb-2">{currentT.registered}</p>
          <p className="text-5xl font-display font-bold text-white tabular-nums">{pantry.length} <span className="text-[11px] text-gold uppercase tracking-widest ml-3 font-sans opacity-50">{currentT.units}</span></p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Registration Control */}
        <div className="lg:col-span-4 space-y-10">
          <div className="glass p-12 rounded-[64px] border-white/5 space-y-10 bg-surface shadow-2xl">
            <h3 className="text-[10px] font-black text-gold uppercase tracking-mega-widest">{currentT.registry}</h3>
            <div className="space-y-6">
              <input 
                type="text" 
                value={newItem}
                onChange={(e) => setNewItem(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addItem(newItem)}
                placeholder={currentT.declare}
                className="w-full bg-black border border-white/5 rounded-[28px] px-10 py-6 outline-none focus:gold-border-subtle transition-all text-[13px] font-light italic tracking-wide"
              />
              <button 
                onClick={() => addItem(newItem)}
                className="w-full py-6 bg-white text-black font-black uppercase tracking-mega-widest text-[10px] rounded-[32px] hover:bg-gold transition-all shadow-xl active:scale-95"
              >
                {currentT.register}
              </button>
            </div>
            
            <div className="flex items-center gap-6 py-6 opacity-20">
              <div className="flex-1 h-px bg-white"></div>
              <span className="text-[8px] text-white uppercase tracking-mega-widest font-black">AI protocol</span>
              <div className="flex-1 h-px bg-white"></div>
            </div>

            <button 
              onClick={startCamera}
              className="w-full py-6 border border-gold/10 bg-gold/[0.01] rounded-[32px] flex items-center justify-center gap-5 text-[10px] font-black uppercase tracking-mega-widest text-gold hover:bg-gold/5 transition-all shadow-sm"
            >
              <CameraIcon className="w-4.5 h-4.5" /> {currentT.vision}
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-8 space-y-12">
          {cameraActive && (
            <div className="glass rounded-[72px] overflow-hidden border-gold/20 animate-in zoom-in-95 relative aspect-video shadow-[0_50px_120px_rgba(0,0,0,0.8)] bg-black">
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover opacity-60" />
              <canvas ref={canvasRef} className="hidden" />
              <div className="absolute inset-0 border-[40px] border-black/80 pointer-events-none flex items-center justify-center">
                 <div className="w-full h-full border border-gold/10 rounded-[56px] animate-pulse"></div>
              </div>
              <div className="absolute bottom-12 left-0 right-0 flex justify-center gap-8 px-12">
                <button 
                  onClick={stopCamera}
                  className="px-12 py-6 glass border-white/5 text-white/30 rounded-[32px] text-[10px] font-black uppercase tracking-mega-widest hover:text-white transition-all backdrop-blur-3xl"
                >
                  {currentT.abort}
                </button>
                <button 
                  onClick={captureAndAnalyze}
                  disabled={isAnalyzing}
                  className="px-16 py-6 bg-gold text-black rounded-[32px] text-[10px] font-black uppercase tracking-mega-widest shadow-2xl hover:bg-gold-light transition-all flex items-center gap-4 disabled:opacity-20"
                >
                  {isAnalyzing ? <LoaderIcon className="animate-spin scale-75" /> : <><SparklesIcon className="w-4.5 h-4.5" /> {currentT.scan}</>}
                </button>
              </div>
            </div>
          )}

          {!cameraActive && (
            <div className="space-y-10">
              <div className="flex items-center justify-between px-8">
                <h3 className="text-[10px] font-black text-white/20 uppercase tracking-mega-widest">Archive Matrix</h3>
                <button 
                  onClick={() => setPantry([])}
                  className="text-[9px] text-red-500/20 uppercase font-black tracking-mega-widest hover:text-red-500 transition-colors"
                >
                  {currentT.purge}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {pantry.length === 0 ? (
                  <div className="col-span-full py-56 text-center glass rounded-[72px] border-dashed border-white/5 bg-surface/10 shadow-inner">
                    <p className="text-white/10 italic text-2xl font-display opacity-40">{currentT.empty}</p>
                  </div>
                ) : (
                  pantry.map(item => (
                    <div key={item} className="glass p-10 rounded-[40px] border-white/5 flex items-center justify-between group hover:gold-border-subtle transition-all duration-1000 bg-surface shadow-lg">
                      <span className="text-[13px] font-light text-white/30 group-hover:text-white/80 transition-colors italic tracking-wide">{item}</span>
                      <button 
                        onClick={() => removeItem(item)}
                        className="w-12 h-12 rounded-full bg-white/[0.01] flex items-center justify-center text-white/5 hover:bg-red-500/10 hover:text-red-500 transition-all border border-transparent hover:border-red-500/20"
                      >
                        &times;
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const CameraIcon = ({ className = "w-4.5 h-4.5" }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export default ShoppingList;
