
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { UserIcon, FireIcon, SparklesIcon } from './Icons';

const profileT = {
  it: { title: "LATI Vault", encryption: "Cifratura LATI", bio: "Biometria", setup: "Setup", health: "Salute", identity: "Identità Digitale", goal: "Matrice Obiettivo", mastery: "Livello di Maestria", arsenal: "Arsenale Tecnologico", blacklist: "Esegui blacklist ingrediente...", filters: "Allergie", empty: "Nessun filtro genetico impostato.", sync: "Sincronizza Vault", protected: "Dati protetti da cifratura end-to-end",
    goals: {
      'weight-loss': 'Perdita Peso (Definizione)',
      'muscle-gain': 'Massa Muscolare (Ipertrofia)',
      'keto': 'Chetogenica (Low Carb/High Fat)',
      'balanced': 'Bilanciata (Benessere Olistico)'
    }
  },
  en: { title: "LATI Vault", encryption: "LATI Encryption", bio: "Biometrics", setup: "Setup", health: "Health", identity: "Digital Identity", goal: "Goal Matrix", mastery: "Mastery Level", arsenal: "Technological Arsenal", blacklist: "Blacklist ingredient...", filters: "Allergies", empty: "No genetic filters set.", sync: "Sync Vault", protected: "Data protected by end-to-end encryption",
    goals: {
      'weight-loss': 'Weight Loss (Definition)',
      'muscle-gain': 'Muscle Gain (Hypertrophy)',
      'keto': 'Keto (Low Carb/High Fat)',
      'balanced': 'Balanced (Holistic Wellness)'
    }
  },
  fr: { title: "Coffre LATI", encryption: "Chiffrement LATI", bio: "Biométrie", setup: "Setup", health: "Santé", identity: "Identité Numérique", goal: "Matrice d'Objectifs", mastery: "Niveau de Maîtrise", arsenal: "Arsenal Tecnologique", blacklist: "Mettre l'ingrédient sur liste noire...", filters: "Allergies", empty: "Aucun filtre génétique défini.", sync: "Synchroniser Coffre", protected: "Données protégées par chiffrement de bout en bout",
    goals: {
      'weight-loss': 'Perte de Poids (Définition)',
      'muscle-gain': 'Prise de Muscle (Hypertrophie)',
      'keto': 'Cétogène (Low Carb/High Fat)',
      'balanced': 'Équilibrée (Bien-être Holistique)'
    }
  },
  es: { title: "Bóveda LATI", encryption: "Cifrado LATI", bio: "Biometría", setup: "Configuración", health: "Salud", identity: "Digital Identity", goal: "Matriz de Objetivos", mastery: "Nivel de Maestría", arsenal: "Arsenal Tecnológico", blacklist: "Poner ingrediente en lista negra...", filters: "Alergias", empty: "No se establecieron filtros genéticos.", sync: "Sincronizar Bóveda", protected: "Datos protegidos por cifrado de extremo a extremo",
    goals: {
      'weight-loss': 'Pérdida de Peso (Definición)',
      'muscle-gain': 'Masa Muscular (Hipertrofia)',
      'keto': 'Cetogénica (Low Carb/High Fat)',
      'balanced': 'Equilibrada (Bienestar Holístico)'
    }
  }
};

const ProfileSettings: React.FC<{ profile: UserProfile, setProfile: (p: UserProfile) => void, lang: string }> = ({ profile, setProfile, lang }) => {
  const currentT = profileT[lang as keyof typeof profileT] || profileT.en;
  const [activeTab, setActiveTab] = useState<'biometric' | 'kitchen' | 'health'>('biometric');

  const handleChange = (field: keyof UserProfile, value: any) => {
    setProfile({ ...profile, [field]: value });
  };

  const tabs = [
    { id: 'biometric', label: currentT.bio, icon: <UserIcon className="w-4.5 h-4.5" /> },
    { id: 'kitchen', label: currentT.setup, icon: <FireIcon className="w-4.5 h-4.5" /> },
    { id: 'health', label: currentT.health, icon: <SparklesIcon className="w-4.5 h-4.5" /> }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-16 animate-in fade-in duration-1000">
      <header className="flex justify-between items-end border-b border-white/5 pb-12">
        <div className="space-y-4">
          <p className="text-[11px] font-black text-gold uppercase tracking-mega-widest opacity-40">{currentT.encryption}</p>
          <h1 className="text-7xl font-display font-bold text-white leading-none">{currentT.title}</h1>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="flex gap-3 p-1.5 bg-white/[0.015] rounded-[32px] w-fit border border-white/5 backdrop-blur-3xl shadow-2xl">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-4 px-10 py-5 rounded-[28px] text-[10px] font-black uppercase tracking-mega-widest transition-all ${
              activeTab === tab.id ? 'bg-white text-black shadow-2xl' : 'text-white/20 hover:text-white/60 hover:bg-white/[0.03]'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-12">
        {activeTab === 'biometric' && (
          <div className="glass p-16 rounded-[64px] space-y-16 animate-in fade-in duration-700 bg-surface shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              <div className="space-y-6">
                <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest opacity-30">{currentT.identity}</label>
                <input 
                  type="text" 
                  value={profile.name} 
                  onChange={(e) => handleChange('name', e.target.value)}
                  className="w-full bg-black border border-white/5 rounded-[32px] px-10 py-7 outline-none focus:gold-border-subtle transition-all text-3xl font-display italic text-white/90 shadow-inner"
                />
              </div>
              <div className="space-y-6">
                <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest opacity-30">{currentT.goal}</label>
                <select 
                  value={profile.goals}
                  onChange={(e) => handleChange('goals', e.target.value)}
                  className="w-full bg-black border border-white/5 rounded-[32px] px-10 py-7 outline-none focus:gold-border-subtle appearance-none transition-all text-xl font-light text-white/70 shadow-inner"
                >
                  <option value="weight-loss">{currentT.goals['weight-loss']}</option>
                  <option value="muscle-gain">{currentT.goals['muscle-gain']}</option>
                  <option value="keto">{currentT.goals['keto']}</option>
                  <option value="balanced">{currentT.goals['balanced']}</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'kitchen' && (
          <div className="glass p-16 rounded-[64px] space-y-16 animate-in fade-in duration-700 bg-surface shadow-2xl">
            <div className="space-y-10">
              <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest opacity-30">{currentT.mastery}</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {['beginner', 'intermediate', 'expert'].map((lvl) => (
                  <button 
                    key={lvl}
                    onClick={() => handleChange('cookingLevel', lvl)}
                    className={`p-12 rounded-[48px] border transition-all duration-700 text-center group ${
                      profile.cookingLevel === lvl ? 'bg-gold/[0.02] border-gold shadow-2xl' : 'bg-black border-white/5 hover:border-gold/10'
                    }`}
                  >
                    <p className={`text-2xl font-display font-bold mb-2 italic ${profile.cookingLevel === lvl ? 'text-gold' : 'text-white/20 group-hover:text-white/40'}`}>
                      {lvl.charAt(0).toUpperCase() + lvl.slice(1)}
                    </p>
                    <p className="text-[10px] text-white/10 uppercase font-black tracking-mega-widest">
                      {lvl === 'beginner' ? 'Foundational' : lvl === 'intermediate' ? 'Proficient' : 'Artisan'}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-10">
              <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest opacity-30">{currentT.arsenal}</label>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                {['forno', 'air-fryer', 'bimby', 'planetaria', 'vaporiera', 'robot', 'sous-vide', 'griglia'].map((tool) => (
                  <button 
                    key={tool}
                    onClick={() => {
                      const tools = profile.tools.includes(tool) 
                        ? profile.tools.filter(t => t !== tool)
                        : [...profile.tools, tool];
                      handleChange('tools', tools);
                    }}
                    className={`px-8 py-5 text-[10px] font-black uppercase tracking-mega-widest rounded-[28px] border transition-all duration-500 flex items-center justify-between group ${
                      profile.tools.includes(tool) ? 'border-gold text-gold bg-gold/[0.02] shadow-lg shadow-gold/5' : 'border-white/5 text-white/10 hover:border-white/20 hover:text-white/40'
                    }`}
                  >
                    <span className="italic">{tool.replace('-', ' ')}</span>
                    <div className={`w-2 h-2 rounded-full transition-all duration-1000 ${profile.tools.includes(tool) ? 'bg-gold shadow-[0_0_12px_rgba(212,175,55,0.6)]' : 'bg-white/5'}`} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'health' && (
          <div className="glass p-16 rounded-[64px] space-y-16 animate-in fade-in duration-700 bg-surface shadow-2xl">
            <div className="space-y-10">
              <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest opacity-30">{currentT.filters}</label>
              <div className="flex gap-6">
                <input 
                    type="text" 
                    placeholder={currentT.blacklist}
                    className="flex-1 bg-black border border-white/5 rounded-[32px] px-10 py-7 outline-none focus:gold-border-subtle transition-all font-light italic text-white/80 shadow-inner"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        const val = e.currentTarget.value.trim();
                        if (val && !profile.allergies.includes(val)) {
                          handleChange('allergies', [...profile.allergies, val]);
                          e.currentTarget.value = '';
                        }
                      }
                    }}
                />
              </div>
              <div className="flex flex-wrap gap-4">
                {profile.allergies.length === 0 ? (
                  <p className="text-sm text-white/10 italic tracking-widest">{currentT.empty}</p>
                ) : (
                  profile.allergies.map(all => (
                    <div key={all} className="bg-red-500/[0.02] text-red-500/50 border border-red-500/10 px-8 py-4 rounded-full text-[10px] font-black uppercase tracking-mega-widest flex items-center gap-6 hover:border-red-500/30 transition-all group">
                      {all}
                      <button 
                        onClick={() => handleChange('allergies', profile.allergies.filter(a => a !== all))}
                        className="opacity-20 hover:opacity-100 transition-opacity text-xl"
                      >&times;</button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center py-16 border-t border-white/5 gap-12">
         <p className="text-[10px] text-white/10 uppercase tracking-mega-widest italic font-light">{currentT.protected}</p>
         <button className="bg-white text-black font-black uppercase tracking-mega-widest px-20 py-7 rounded-[36px] hover:bg-gold transition-all shadow-2xl active:scale-95 shadow-white/5">
            {currentT.sync}
         </button>
      </div>
    </div>
  );
};

export default ProfileSettings;
