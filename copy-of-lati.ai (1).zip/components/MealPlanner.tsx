
import React, { useState } from 'react';
import { LoaderIcon, SparklesIcon, CalendarIcon } from './Icons';
import { UserProfile } from '../types';
import { generateWeeklyPlan } from '../services/geminiService';

const plannerT = {
  it: { title: "Protocollo Settimanale", sub: "Rituali Metabolici", goal: "Obiettivo:", sync: "Sincronizzazione costanti biometriche...", tailoring: "Orchestrazione unità culinarie molecolari...", initialize: "Inizializza Protocollo Perfetto", re: "Ri-Sintetizza Matrice", vault: "Nessun rituale attivo nel caveau", define: "Inizia la sintesi per definire il tuo percorso nutrizionale", sigma: "Somma", days: ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'] },
  en: { title: "Weekly Protocol", sub: "Metabolic Rituals", goal: "Goal Focus:", sync: "Mapping Biometric Constants...", tailoring: "Orchestrating tailored molecular culinary units...", initialize: "Initialize Perfect Protocol", re: "Re-Synthesize Matrix", vault: "No ritual active in vault", define: "Initiate synthesis to define your nutritional path", sigma: "Sigma", days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] },
  fr: { title: "Protocole Hebdomadaire", sub: "Rituels Métaboliques", goal: "Objectif :", sync: "Cartographie des constantes biométriques...", tailoring: "Orchestration des unités culinaires moléculaires...", initialize: "Initialiser le Protocole Parfait", re: "Re-Synthétiser la Matrice", vault: "Aucun rituel actif dans le coffre", define: "Lancez la synthèse pour définir votre parcours nutritionnel", sigma: "Somme", days: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'] },
  es: { title: "Protocolo Semanal", sub: "Rituales Metabólicos", goal: "Enfoque de objetivo:", sync: "Mapeo de constantes biométricas...", tailoring: "Orquestando unidades culinarias moleculares...", initialize: "Inicializar Protocolo Perfecto", re: "Re-Sintetizar Matriz", vault: "Ningún ritual activo en la bóveda", define: "Inicia la síntesis para definir tu camino nutricional", sigma: "Sigma", days: ['Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab', 'Dom'] }
};

const MealPlanner: React.FC<{ profile: UserProfile, lang: string }> = ({ profile, lang }) => {
  const currentT = plannerT[lang as keyof typeof plannerT] || plannerT.en;
  const [isGenerating, setIsGenerating] = useState(false);
  const [weeklyPlan, setWeeklyPlan] = useState<Record<string, any> | null>(null);

  const generatePlan = async () => {
    setIsGenerating(true);
    try {
      const plan = await generateWeeklyPlan(profile);
      setWeeklyPlan(plan);
    } catch (error) {
      console.error("Failed to generate plan", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const planDays = weeklyPlan ? Object.keys(weeklyPlan) : [];

  return (
    <div className="space-y-20 animate-in fade-in duration-1000">
      <header className="flex flex-col xl:flex-row justify-between items-start xl:items-end border-b border-white/5 pb-12 gap-12">
        <div className="space-y-5">
          <p className="text-[10px] font-black text-gold uppercase tracking-mega-widest opacity-40">{currentT.sub}</p>
          <h1 className="text-7xl font-display font-bold leading-tight tracking-tight text-white">{currentT.title}</h1>
          <div className="flex flex-wrap items-center gap-5">
            <p className="text-[12px] text-white/30 font-light flex items-center gap-4 italic">
              {currentT.goal} 
              <span className="text-gold font-black bg-gold/[0.01] px-6 py-2 rounded-full border border-gold/10 tracking-mega-widest uppercase text-[9px] shadow-sm">
                {profile.goals.replace('-', ' ')}
              </span>
            </p>
            {profile.allergies.length > 0 && (
              <span className="text-[9px] text-red-400 font-black uppercase tracking-mega-widest bg-red-500/[0.02] px-6 py-2 rounded-full border border-red-500/10">
                Safe-Allergy Enabled
              </span>
            )}
          </div>
        </div>
        <button 
          onClick={generatePlan}
          disabled={isGenerating}
          className="bg-white text-black font-black uppercase tracking-mega-widest text-[10px] px-16 py-7 rounded-[36px] hover:bg-gold hover:scale-[1.02] transition-all shadow-2xl flex items-center gap-6 disabled:opacity-10 active:scale-95"
        >
          {isGenerating ? <LoaderIcon className="animate-spin scale-75" /> : <SparklesIcon className="w-4 h-4" />}
          {weeklyPlan ? currentT.re : currentT.initialize}
        </button>
      </header>

      {isGenerating && (
        <div className="py-64 text-center space-y-12 glass rounded-[80px] border-gold/10 relative overflow-hidden bg-surface shadow-2xl">
           <div className="absolute inset-0 bg-gold/[0.005] animate-subtle-pulse"></div>
           <div className="w-28 h-28 border-t-2 border-gold rounded-full animate-spin mx-auto shadow-[0_0_50px_rgba(212,175,55,0.1)]"></div>
           <div className="space-y-4 relative z-10">
              <p className="text-gold text-[11px] font-black uppercase tracking-mega-widest animate-pulse">{currentT.sync}</p>
              <p className="text-white/10 text-[10px] font-light italic tracking-ultra-widest">{currentT.tailoring}</p>
           </div>
        </div>
      )}

      {!isGenerating && !weeklyPlan && (
        <div className="py-56 text-center glass rounded-[80px] border-white/5 border-dashed flex flex-col items-center justify-center space-y-12 group hover:gold-border-subtle transition-all duration-1000 bg-surface/20 cursor-pointer shadow-inner" onClick={generatePlan}>
          <div className="w-28 h-28 bg-white/[0.01] rounded-full flex items-center justify-center group-hover:scale-110 transition-all duration-1000 border border-white/5 group-hover:shadow-[0_0_50px_rgba(212,175,55,0.05)]">
             <CalendarIcon className="w-12 h-12 text-white/5 group-hover:text-gold/20 transition-colors" />
          </div>
          <div className="space-y-5">
            <p className="text-white/10 font-display italic text-3xl group-hover:text-white/30 transition-colors">{currentT.vault}</p>
            <p className="text-[10px] text-white/5 uppercase font-black tracking-mega-widest">{currentT.define}</p>
          </div>
        </div>
      )}

      {weeklyPlan && !isGenerating && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-7 gap-8">
          {planDays.map(day => (
            <div key={day} className="glass p-10 rounded-[56px] flex flex-col gap-10 min-h-[550px] border-white/5 hover:gold-border-subtle transition-all duration-1000 group relative overflow-hidden bg-surface shadow-xl">
              <div className="absolute top-0 left-0 w-full h-[1.5px] bg-gradient-to-r from-transparent via-gold/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              <h4 className="text-[11px] font-black text-gold uppercase tracking-mega-widest text-center pb-8 border-b border-white/5 opacity-50 group-hover:opacity-100 transition-opacity">{day}</h4>
              
              <div className="space-y-8">
                <MealSlot type="MORN" name={weeklyPlan[day].breakfast} />
                <MealSlot type="NOON" name={weeklyPlan[day].lunch} />
                <MealSlot type="EVEN" name={weeklyPlan[day].dinner} />
              </div>
              
              <div className="mt-auto pt-10 border-t border-white/5">
                <div className="flex justify-between items-baseline">
                  <span className="text-[9px] text-white/10 font-black tracking-mega-widest uppercase">{currentT.sigma}</span>
                  <span className="text-white font-display font-bold text-2xl tabular-nums">{weeklyPlan[day].totalKcal} <span className="text-[10px] text-gold/30 uppercase font-sans tracking-widest ml-2 font-normal">kcal</span></span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const MealSlot: React.FC<{ type: string, name: string }> = ({ type, name }) => (
  <div className="p-8 bg-black rounded-[40px] border border-white/[0.01] hover:gold-border-subtle transition-all duration-500 cursor-pointer group/slot relative overflow-hidden shadow-inner">
    <p className="text-[8px] text-white/10 uppercase font-black mb-3 tracking-mega-widest group-hover/slot:text-gold/30 transition-colors">{type}</p>
    <p className="text-[12px] font-medium text-white/30 leading-snug group-hover/slot:text-white/80 transition-colors italic pr-10 line-clamp-2 h-8">{name}</p>
  </div>
);

export default MealPlanner;
