
import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { SparklesIcon, LoaderIcon } from './Icons';

const authT = {
  it: { login: "Sincronizza Identità", register: "Inizia Esperienza", aura: "Sincronizza Aura", orchestrate: "Profilo", access: "Accesso Identità Premium", ritual: "Sintesi Rituale — Fase", key: "Chiave di Sicurezza", account: "Credenziali", identifier: "Nome Identificativo", matrix: "Matrice Obiettivo", biological: "Allergie", arsenal: "Arsenale Cucina", mastery: "Maestria", lang: "Scegli la tua Lingua", next: "Continua", back: "Indietro", welcome: "L'identità LATI sta sintetizzando il tuo profilo. Sei pronto per l'eccellenza.", errorLogin: "Credenziali non valide.", errorExists: "Identità già registrata.", errorEmpty: "Compila tutti i campi.",
    goals: {
      'weight-loss': 'Perdita Peso (Riduzione massa grassa)',
      'muscle-gain': 'Massa Muscolare (Ipertrofia/Potenziamento)',
      'keto': 'Chetogenica (Grassi alti, Carboidrati quasi nulli)',
      'balanced': 'Bilanciata (Mantenimento e benessere olistico)'
    }
  },
  en: { login: "Sync Identity", register: "Begin Experience", aura: "Synchronize Aura", orchestrate: "Orchestrate Profile", access: "Premium Identity Access", ritual: "Ritual Synthesis — Phase", key: "Security Key", account: "Credentials", identifier: "Identity Marker", matrix: "Goal Matrix", biological: "Allergies", arsenal: "Kitchen Arsenal", mastery: "Mastery Level", lang: "Choose your Language", next: "Continue", back: "Back", welcome: "The LATI identity matrix is synthesizing your profile. You are ready for excellence.", errorLogin: "Invalid credentials.", errorExists: "Identity already registered.", errorEmpty: "Please fill all fields.",
    goals: {
      'weight-loss': 'Weight Loss (Fat reduction)',
      'muscle-gain': 'Muscle Gain (Hypertrophy/Bulking)',
      'keto': 'Keto (High fat, ultra-low carbs)',
      'balanced': 'Balanced (Maintenance and holistic well-being)'
    }
  },
  fr: { login: "Synchroniser", register: "Débuter Expérience", aura: "Synchroniser Aura", orchestrate: "Orchestrer Profil", access: "Accès Identité Premium", ritual: "Synthèse Rituelle — Fase", key: "Clé de Sécurité", account: "Identifiants", identifier: "Identifiant", matrix: "Matrice d'Objectifs", biological: "Allergies", arsenal: "Arsenal Cuisine", mastery: "Maîtrise", lang: "Choisissez votre Langue", next: "Continuer", back: "Retour", welcome: "La matrice LATI synthétise votre profil. Vous êtes prêt pour l'excellence.", errorLogin: "Identifiants invalides.", errorExists: "Identité déjà enregistrée.", errorEmpty: "Veuillez remplir tous les champs.",
    goals: {
      'weight-loss': 'Perte de Poids (Réduction des graisses)',
      'muscle-gain': 'Prise de Muscle (Hypertrophie)',
      'keto': 'Cétogène (Gras élevés, glucides ultra-faibles)',
      'balanced': 'Équilibrée (Maintien et bien-être holistique)'
    }
  },
  es: { login: "Sincronizar", register: "Iniciar Esperiencia", aura: "Sincronizar Aura", orchestrate: "Orquestar Perfil", access: "Acceso Identidad Premium", ritual: "Síntesis de Ritual — Fase", key: "Llave de Seguridad", account: "Credenciales", identifier: "Marcador de Identidad", matrix: "Matriz de Objetivos", biological: "Alergias", arsenal: "Arsenal Cocina", mastery: "Maestría", lang: "Elige tu Idioma", next: "Continuar", back: "Atrás", welcome: "La matriz de identidad LATI está sintetizando tu perfil. Estás listo para la excelencia.", errorLogin: "Credenciales no válidas.", errorExists: "Identidad ya registrada.", errorEmpty: "Por favor complete todos los campos.",
    goals: {
      'weight-loss': 'Pérdida de Peso (Reducción de grasa)',
      'muscle-gain': 'Masa Muscular (Hipertrofia/Volumen)',
      'keto': 'Cetogénica (Grasas altas, carbohidratos mínimos)',
      'balanced': 'Equilibrada (Mantenimiento y bienestar holístico)'
    }
  }
};

interface StoredUser {
  email: string;
  key: string;
  profile: UserProfile;
}

const Auth: React.FC<{ onComplete: (profile: UserProfile) => void }> = ({ onComplete }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [allergyInput, setAllergyInput] = useState('');
  const [selectedLang, setSelectedLang] = useState<'it' | 'en' | 'fr' | 'es'>('it');
  
  // Auth fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [formData, setFormData] = useState<UserProfile>({
    name: '',
    goals: 'balanced',
    allergies: [],
    cookingLevel: 'intermediate',
    tools: ['oven'],
    budget: 'medium',
    timePerMeal: 30,
    language: 'it'
  });

  const currentT = authT[selectedLang];
  const totalSteps = 7;

  const next = () => { 
    setError('');
    setStep(s => s + 1); 
    window.scrollTo(0,0); 
  };
  const back = () => { 
    setError('');
    setStep(s => s - 1); 
    window.scrollTo(0,0); 
  };

  const getUsers = (): StoredUser[] => {
    const data = localStorage.getItem('lati_vault_users');
    return data ? JSON.parse(data) : [];
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError(currentT.errorEmpty);
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const users = getUsers();
      const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.key === password);
      
      if (user) {
        onComplete(user.profile);
      } else {
        setError(currentT.errorLogin);
        setIsLoading(false);
      }
    }, 1500);
  };

  const handleRegisterComplete = () => {
    setIsLoading(true);
    setError('');

    setTimeout(() => {
      const users = getUsers();
      if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
        setError(currentT.errorExists);
        setIsLoading(false);
        setStep(2); // Go back to credentials step
        return;
      }

      const finalProfile: UserProfile = { ...formData, language: selectedLang };
      const newUser: StoredUser = {
        email,
        key: password,
        profile: finalProfile
      };

      users.push(newUser);
      localStorage.setItem('lati_vault_users', JSON.stringify(users));
      onComplete(finalProfile);
    }, 2000);
  };

  const toggleAuthMode = () => { 
    setIsLogin(!isLogin); 
    setStep(1); 
    setError('');
  };

  return (
    <div className="fixed inset-0 bg-black z-[100] overflow-y-auto py-24 px-12 scroll-smooth flex items-center justify-center">
      <div className="fixed top-0 right-0 w-full h-full bg-gold/[0.04] blur-[300px] rounded-full -z-10 animate-subtle-pulse pointer-events-none"></div>
      
      <div className="max-w-2xl w-full mx-auto relative">
        {/* elegant floating logo at the very top */}
        <div className="mb-12 flex flex-col items-center animate-in fade-in slide-in-from-top-12 duration-1000">
           <div className="w-px h-16 bg-gradient-to-b from-transparent via-gold/40 to-transparent mb-8"></div>
           <h2 className="text-4xl font-display font-bold tracking-[0.6em] text-gold text-glow leading-none select-none">LATI.AI</h2>
           <div className="w-12 h-px bg-gold/20 mt-6"></div>
        </div>

        {!isLogin && (
          <div className="absolute -top-12 left-0 right-0 flex justify-center gap-4 px-20">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <div key={i} className={`h-1 rounded-full transition-all duration-1000 ${step >= i + 1 ? 'bg-gold w-14 shadow-[0_0_20px_rgba(212,175,55,0.4)]' : 'bg-white/5 w-4'}`}></div>
            ))}
          </div>
        )}

        <div className="glass p-16 md:p-24 rounded-[84px] border-white/5 shadow-[0_60px_140px_rgba(0,0,0,0.9)] space-y-16 animate-in fade-in zoom-in-95 duration-1000 bg-surface">
          <header className="text-center space-y-4">
            <p className="text-white/20 text-[9px] uppercase tracking-mega-widest font-black italic">
              {isLogin ? currentT.access : `${currentT.ritual} ${step}/${totalSteps}`}
            </p>
          </header>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-[32px] text-center animate-in fade-in slide-in-from-top-4">
              <p className="text-red-400 text-xs font-bold uppercase tracking-widest">{error}</p>
            </div>
          )}

          {isLogin ? (
            <form onSubmit={handleLogin} className="space-y-16 animate-in fade-in slide-in-from-bottom-8 duration-700">
              <div className="space-y-10">
                <div className="space-y-3">
                   <label className="text-[8px] text-gold/30 uppercase tracking-widest ml-10 font-black">Identity Identifier</label>
                   <input 
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email" 
                      className="w-full bg-black border border-white/5 rounded-[36px] px-12 py-8 outline-none focus:gold-border-subtle transition-all text-2xl font-light italic text-white/90 shadow-inner" 
                   />
                </div>
                <div className="space-y-3">
                   <label className="text-[8px] text-gold/30 uppercase tracking-widest ml-10 font-black">Security Sequence</label>
                   <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={currentT.key} 
                      className="w-full bg-black border border-white/5 rounded-[36px] px-12 py-8 outline-none focus:gold-border-subtle transition-all text-2xl font-light italic text-white/90 shadow-inner" 
                   />
                </div>
              </div>
              <div className="space-y-10">
                <button type="submit" disabled={isLoading} className="w-full py-8 bg-white text-black font-black uppercase tracking-mega-widest text-[11px] rounded-[40px] hover:bg-gold transition-all shadow-2xl active:scale-95 disabled:opacity-50">
                  {isLoading ? <LoaderIcon className="animate-spin scale-75" /> : currentT.aura}
                </button>
                <div className="text-center">
                  <p className="text-[12px] text-white/20 font-light italic">
                    New aura? <button type="button" onClick={toggleAuthMode} className="text-gold font-bold ml-2 underline underline-offset-8 decoration-gold/20 hover:decoration-gold/50 transition-all">{currentT.orchestrate}</button>
                  </p>
                </div>
              </div>
            </form>
          ) : (
            <div className="space-y-16">
              {step === 1 && (
                <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
                  <div className="space-y-8">
                    <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest ml-6">{currentT.lang}</label>
                    <div className="grid grid-cols-2 gap-6">
                      {['it', 'en', 'fr', 'es'].map(l => (
                        <button key={l} onClick={() => setSelectedLang(l as any)} className={`py-6 rounded-[28px] border text-[10px] font-black uppercase tracking-mega-widest transition-all ${selectedLang === l ? 'bg-gold text-black border-gold shadow-2xl' : 'border-white/5 text-white/20 hover:border-gold/20'}`}>
                          {l === 'it' ? 'Italiano' : l === 'en' ? 'English' : l === 'fr' ? 'Français' : 'Español'}
                        </button>
                      ))}
                    </div>
                  </div>
                  <button onClick={next} className="w-full py-8 bg-white text-black font-black rounded-[40px] text-[10px] uppercase tracking-mega-widest">{currentT.next}</button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
                  <div className="space-y-8">
                    <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest ml-6">{currentT.account}</label>
                    <input 
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email" 
                      className="w-full bg-black border border-white/5 rounded-[36px] px-12 py-7 outline-none focus:gold-border-subtle text-xl text-white/90" 
                    />
                    <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={currentT.key} 
                      className="w-full bg-black border border-white/5 rounded-[36px] px-12 py-7 outline-none focus:gold-border-subtle text-xl text-white/90" 
                    />
                  </div>
                  <div className="flex gap-6">
                    <button onClick={back} className="flex-1 py-7 bg-white/5 text-white/20 rounded-[36px] text-[10px] uppercase font-black tracking-widest">{currentT.back}</button>
                    <button onClick={() => { if(!email || !password) setError(currentT.errorEmpty); else next(); }} className="flex-[2] py-7 bg-white text-black font-black rounded-[40px] text-[10px] uppercase tracking-mega-widest">{currentT.next}</button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
                  <div className="space-y-8">
                    <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest ml-6">{currentT.identifier}</label>
                    <input autoFocus value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="..." className="w-full bg-black border border-white/5 rounded-[36px] px-12 py-10 outline-none focus:gold-border-subtle text-5xl font-display font-light italic text-glow text-white/90" />
                  </div>
                  <div className="flex gap-6">
                    <button onClick={back} className="flex-1 py-7 bg-white/5 text-white/20 rounded-[36px] text-[10px] uppercase font-black tracking-widest">{currentT.back}</button>
                    <button onClick={next} disabled={!formData.name} className="flex-[2] py-7 bg-white text-black font-black rounded-[40px] text-[10px] uppercase tracking-mega-widest disabled:opacity-5">{currentT.next}</button>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
                  <div className="space-y-8">
                    <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest ml-6">{currentT.matrix}</label>
                    <div className="grid grid-cols-1 gap-5">
                      {['weight-loss', 'muscle-gain', 'keto', 'balanced'].map(g => (
                        <button key={g} onClick={() => setFormData({...formData, goals: g as any})} className={`p-8 rounded-[36px] border text-left transition-all ${formData.goals === g ? 'bg-gold/[0.03] border-gold shadow-xl' : 'bg-black border-white/5 hover:border-white/10'}`}>
                          <p className={`text-[11px] font-black uppercase tracking-mega-widest mb-2 ${formData.goals === g ? 'text-gold' : 'text-white/20'}`}>
                            {g.replace('-',' ').toUpperCase()}
                          </p>
                          <p className="text-[10px] text-white/30 font-light italic">
                            {currentT.goals[g as keyof typeof currentT.goals]}
                          </p>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-6">
                    <button onClick={back} className="flex-1 py-7 bg-white/5 text-white/20 rounded-[36px] text-[10px] uppercase font-black tracking-widest">{currentT.back}</button>
                    <button onClick={next} className="flex-[2] py-7 bg-white text-black font-black rounded-[40px] text-[10px] uppercase tracking-mega-widest">{currentT.next}</button>
                  </div>
                </div>
              )}

              {step === 5 && (
                <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
                  <div className="space-y-8">
                    <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest ml-6">{currentT.biological}</label>
                    <div className="flex gap-4">
                      <input 
                        value={allergyInput} 
                        onChange={e => setAllergyInput(e.target.value)} 
                        onKeyDown={e => {
                          if (e.key === 'Enter') {
                            setFormData({...formData, allergies: [...formData.allergies, allergyInput]});
                            setAllergyInput('');
                          }
                        }} 
                        placeholder="..." 
                        className="flex-1 bg-black border border-white/5 rounded-[32px] px-10 py-6 text-xl font-light italic text-white/90" 
                      />
                    </div>
                    <div className="flex flex-wrap gap-4 min-h-[80px]">
                      {formData.allergies.map(a => <span key={a} className="bg-white/5 px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest text-white/70">{a}</span>)}
                    </div>
                  </div>
                  <div className="flex gap-6">
                    <button onClick={back} className="flex-1 py-7 bg-white/5 text-white/20 rounded-[36px] text-[10px] uppercase font-black tracking-widest">{currentT.back}</button>
                    <button onClick={next} className="flex-[2] py-7 bg-white text-black font-black rounded-[40px] text-[10px] uppercase tracking-mega-widest">{currentT.next}</button>
                  </div>
                </div>
              )}

              {step === 6 && (
                <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
                  <div className="space-y-8">
                    <label className="block text-[10px] text-gold uppercase font-black tracking-mega-widest ml-6">{currentT.arsenal}</label>
                    <div className="grid grid-cols-2 gap-4">
                      {['oven', 'robotic', 'steamer', 'grill', 'air-fryer', 'sous-vide'].map(t => (
                        <button 
                          key={t} 
                          onClick={() => setFormData({...formData, tools: formData.tools.includes(t) ? formData.tools.filter(x => x !== t) : [...formData.tools, t]})} 
                          className={`py-6 rounded-[28px] border text-[10px] font-black uppercase tracking-mega-widest transition-all ${formData.tools.includes(t) ? 'bg-gold text-black border-gold shadow-lg' : 'bg-black border-white/5 text-white/10'}`}
                        >
                          {t.replace('-', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-6">
                    <button onClick={back} className="flex-1 py-7 bg-white/5 text-white/20 rounded-[36px] text-[10px] uppercase font-black tracking-widest">{currentT.back}</button>
                    <button onClick={next} className="flex-[2] py-7 bg-white text-black font-black rounded-[40px] text-[10px] uppercase tracking-mega-widest">{currentT.next}</button>
                  </div>
                </div>
              )}

              {step === 7 && (
                <div className="space-y-16 animate-in fade-in slide-in-from-right-8 duration-700">
                  <div className="p-16 glass rounded-[64px] border-gold/10 relative overflow-hidden bg-surface shadow-2xl">
                    <div className="absolute inset-0 bg-gold/[0.01] animate-subtle-pulse"></div>
                    <p className="text-[18px] text-white/40 leading-relaxed font-display italic text-center relative z-10 tracking-wide">
                      "{currentT.welcome}"
                    </p>
                  </div>
                  <div className="flex gap-6">
                    <button onClick={back} className="flex-1 py-7 bg-white/5 text-white/20 rounded-[36px] text-[10px] uppercase font-black tracking-widest">{currentT.back}</button>
                    <button onClick={handleRegisterComplete} disabled={isLoading} className="flex-[2] py-7 bg-gold text-black font-black rounded-[40px] text-[11px] uppercase tracking-mega-widest shadow-2xl flex items-center justify-center gap-6 disabled:opacity-50">
                      {isLoading ? <LoaderIcon className="animate-spin scale-75" /> : <><SparklesIcon className="w-5 h-5"/> {currentT.register}</>}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        <p className="mt-16 text-center text-[8px] text-white/10 uppercase tracking-mega-widest font-black">
          © 2025 LATI.AI — Molecular Gastronomy Protocol — All Rights Reserved
        </p>
      </div>
    </div>
  );
};

export default Auth;
