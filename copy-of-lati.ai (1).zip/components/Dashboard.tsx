
import React from 'react';
import { UserProfile } from '../types';
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { SparklesIcon } from './Icons';

const data = [
  { name: 'Lun', kcal: 2100 },
  { name: 'Mar', kcal: 1850 },
  { name: 'Mer', kcal: 2300 },
  { name: 'Gio', kcal: 2100 },
  { name: 'Ven', kcal: 1950 },
  { name: 'Sab', kcal: 2500 },
  { name: 'Dom', kcal: 2200 },
];

const dashboardT = {
  it: { title: "Benvenuto", identity: "Pannello Identità", daily: "Flusso Giornaliero", protocol: "Protocollo", signature: "Firma Metabolica", synthesis: "Sintesi Attiva", pulse: "Impulso Neurale", blueprint: "Rivela Schema" },
  en: { title: "Welcome", identity: "Identity Dashboard", daily: "Daily Flux", protocol: "Protocol", signature: "Metabolic Signature", synthesis: "Active Synthesis", pulse: "Neural Pulse", blueprint: "Reveal Blueprint" },
  fr: { title: "Bienvenue", identity: "Tableau d'Identité", daily: "Flux Quotidien", protocol: "Protocole", signature: "Signature Métabolique", synthesis: "Synthèse Active", pulse: "Impulsion Neurale", blueprint: "Révéler Schéma" },
  es: { title: "Bienvenido", identity: "Panel de Identidad", daily: "Flujo Diario", protocol: "Protocolo", signature: "Firma Metabólica", synthesis: "Síntesis Activa", pulse: "Impulso Neural", blueprint: "Revelar Esquema" }
};

const Dashboard: React.FC<{ profile: UserProfile, lang: string }> = ({ profile, lang }) => {
  const currentT = dashboardT[lang as keyof typeof dashboardT] || dashboardT.en;

  return (
    <div className="space-y-20 animate-in fade-in slide-in-from-bottom-6 duration-1000">
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-12">
        <div className="space-y-4">
          <p className="text-[9px] font-black text-gold uppercase tracking-mega-widest opacity-40">{currentT.identity}</p>
          <h1 className="text-7xl font-display font-bold leading-tight tracking-tight text-white">{currentT.title}, <span className="text-gold italic">{profile.name}</span></h1>
        </div>
        <div className="flex gap-8">
          <div className="glass px-12 py-8 rounded-[36px] border-white/5">
            <p className="text-[8px] text-white/20 uppercase tracking-mega-widest mb-3">{currentT.daily}</p>
            <p className="text-4xl font-bold font-display tracking-tight text-white">2,450 <span className="text-[10px] text-gold uppercase tracking-widest ml-2 font-sans opacity-50">kcal</span></p>
          </div>
          <div className="glass px-12 py-8 rounded-[36px] gold-border-subtle bg-gold/[0.01]">
            <p className="text-[8px] text-gold/30 uppercase tracking-mega-widest mb-3">{currentT.protocol}</p>
            <p className="text-2xl font-bold font-display uppercase tracking-ultra-widest text-gold">{profile.goals.replace('-', ' ')}</p>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-12">
        {/* Weekly Stats */}
        <div className="xl:col-span-2 glass rounded-[56px] p-16 overflow-hidden relative border-white/5 shadow-2xl bg-surface">
          <div className="flex items-center justify-between mb-16">
            <h3 className="text-[10px] font-black uppercase tracking-mega-widest text-white/30">{currentT.signature}</h3>
            <div className="flex items-center gap-4">
              <span className="w-2 h-2 rounded-full bg-gold/50 animate-subtle-pulse shadow-[0_0_10px_rgba(212,175,55,0.4)]"></span>
              <span className="text-[8px] text-gold/60 uppercase font-black tracking-widest">{currentT.synthesis}</span>
            </div>
          </div>
          <div className="h-96 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorKcal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.12}/>
                    <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#ffffff10" fontSize={10} tickLine={false} axisLine={false} tick={{fill: '#ffffff20'}} dy={15} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#080808', border: '1px solid rgba(212, 175, 55, 0.1)', borderRadius: '24px', fontSize: '11px', backdropFilter: 'blur(20px)', color: '#fff' }}
                  itemStyle={{ color: '#D4AF37' }}
                  cursor={{ stroke: '#D4AF37', strokeWidth: 1, strokeDasharray: '6 6' }}
                />
                <Area type="monotone" dataKey="kcal" stroke="#D4AF37" strokeWidth={1.5} fillOpacity={1} fill="url(#colorKcal)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Current Recommendation */}
        <div className="glass rounded-[56px] p-12 bg-gradient-to-br from-gold/[0.03] to-transparent flex flex-col border-white/5 relative overflow-hidden group shadow-2xl">
          <div className="absolute top-0 right-0 p-8">
             <div className="w-12 h-12 rounded-full bg-gold/5 border border-gold/10 flex items-center justify-center">
                <SparklesIcon className="w-5 h-5 text-gold/40" />
             </div>
          </div>
          <h3 className="text-[9px] font-black text-gold/40 uppercase tracking-mega-widest mb-8">{currentT.pulse}</h3>
          <div className="aspect-[4/3] rounded-[40px] bg-black mb-10 overflow-hidden shadow-inner border border-white/5 relative group-hover:gold-border-subtle transition-all duration-1000">
             <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover transition-transform duration-2000 group-hover:scale-110 opacity-70 group-hover:opacity-90" alt="Meal" />
             <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
          </div>
          <h4 className="text-4xl font-display font-bold mb-4 tracking-tight text-white">Salmone & Zenzero</h4>
          <p className="text-[12px] text-white/30 mb-12 flex-1 leading-relaxed font-light italic tracking-wide">Orchestrated to optimize post-performance recovery.</p>
          <button className="w-full py-6 bg-white text-black font-black uppercase tracking-mega-widest text-[10px] rounded-3xl hover:bg-gold transition-all shadow-xl shadow-white/5">
            {currentT.blueprint}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
        <MacroCard label="Protein" value="145g" target="160g" />
        <MacroCard label="Carbs" value="210g" target="250g" />
        <MacroCard label="Lipids" value="65g" target="70g" />
        <MacroCard label="Vitals" value="32g" target="30g" />
      </div>
    </div>
  );
};

const MacroCard: React.FC<{ label: string, value: string, target: string }> = ({ label, value, target }) => (
  <div className="glass p-12 rounded-[48px] border-white/5 hover:gold-border-subtle transition-all duration-700 group bg-surface">
    <p className="text-[8px] text-white/20 uppercase font-black mb-5 tracking-mega-widest group-hover:text-gold/40 transition-colors">{label}</p>
    <div className="flex items-baseline gap-3 mb-8">
      <span className="text-5xl font-display font-bold text-white">{value}</span>
      <span className="text-[10px] text-white/10 font-bold tracking-mega-widest uppercase">/ {target}</span>
    </div>
    <div className="w-full h-[1.5px] bg-white/[0.03] rounded-full overflow-hidden">
      <div className={`h-full bg-gold shadow-[0_0_15px_rgba(212,175,55,0.4)] opacity-70 group-hover:opacity-100 transition-all duration-1000`} style={{ width: '80%' }}></div>
    </div>
  </div>
);

export default Dashboard;
