
import React, { useState, useMemo } from 'react';
import { UserProfile, Recipe } from '../types';
import { generateRecipe, generateRecipeImage } from '../services/geminiService';
import { LoaderIcon, SparklesIcon, FireIcon, ClockIcon, UserIcon } from './Icons';

const recipeT = {
  it: { title: "Chef AI", sub: "Laboratorio di Gastronomia Neurale", inventory: "Selezione Inventario", manifest: "Manifesta ingredienti per la sintesi:", filters: "Filtro Allergie Attivo", synthesize: "Sintetizza Rituale", awaiting: "In attesa di selezione...", define: "Definisci ingredienti per avviare il protocollo", progress: "Sintesi in corso", mapping: "Mappatura profili gastronomici molecolari...", elemental: "Sintesi Elementale", orchestration: "Protocollo d'Orchestrazione" },
  en: { title: "Chef AI", sub: "Neural Gastronomy Lab", inventory: "Inventory Select", manifest: "Manifest ingredients for synthesis:", filters: "Allergy Filter Engaged", synthesize: "Synthesize Ritual", awaiting: "Awaiting selection...", define: "Define ingredients to initiate orchestral protocol", progress: "Synthesis in progress", mapping: "Mapping molecular gastronomic profiles...", elemental: "Elemental Synthesis", orchestration: "Orchestration Protocol" },
  fr: { title: "Chef AI", sub: "Laboratoire de Gastronomie Neurale", inventory: "Sélection d'Inventaire", manifest: "Manifester les ingrédients pour la synthèse :", filters: "Filtre Allergies Engagé", synthesize: "Synthétiser le Rituel", awaiting: "En attente de sélection...", define: "Définissez les ingrédients pour lancer le protocole", progress: "Synthèse en cours", mapping: "Cartographie des profils moléculaires...", elemental: "Synthèse Élémentaire", orchestration: "Protocole d'Orchestration" },
  es: { title: "Chef AI", sub: "Laboratorio de Gastronomía Neural", inventory: "Selección de Inventario", manifest: "Manifestar ingredientes para la síntesis:", filters: "Filtro Alergias Activado", synthesize: "Sintetizar Ritual", awaiting: "Esperando selección...", define: "Define ingredientes para iniciar el protocolo", progress: "Síntesis en curso", mapping: "Mapeo de perfiles moleculares...", elemental: "Síntesis Elemental", orchestration: "Protocolo de Orquestación" }
};

const RecipeGenerator: React.FC<{ profile: UserProfile, globalPantry: string[], lang: string }> = ({ profile, globalPantry, lang }) => {
  const currentT = recipeT[lang as keyof typeof recipeT] || recipeT.en;
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [activeStep, setActiveStep] = useState(0);

  const filteredPantry = useMemo(() => {
    return globalPantry.filter(item => {
      const lowerItem = item.toLowerCase();
      return !profile.allergies.some(allergy => lowerItem.includes(allergy.toLowerCase()));
    });
  }, [globalPantry, profile.allergies]);

  const toggleIngredient = (item: string) => {
    setSelectedIngredients(prev => 
      prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]
    );
  };

  const handleGenerate = async () => {
    if (selectedIngredients.length === 0) return;
    
    setLoading(true);
    try {
      const finalPrompt = `Create a gourmet recipe using EXCLUSIVELY or MAINLY these selected ingredients: ${selectedIngredients.join(', ')}.`;
      const newRecipe = await generateRecipe(finalPrompt, profile);
      const imageUrl = await generateRecipeImage(newRecipe.title);
      setRecipe({ ...newRecipe, image: imageUrl });
      setActiveStep(0);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-20 animate-in fade-in duration-1000">
      <div className="text-center space-y-6">
        <h1 className="text-9xl font-display font-bold text-white tracking-tighter leading-none">{currentT.title}</h1>
        <p className="text-gold text-[10px] font-black uppercase tracking-mega-widest opacity-40">
          {currentT.sub}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Ingredients Panel */}
        <div className="lg:col-span-4 glass p-14 rounded-[64px] border-white/5 h-fit space-y-12 relative overflow-hidden bg-surface shadow-2xl">
          <header className="space-y-4 border-b border-white/5 pb-10">
            <h3 className="text-[10px] font-black text-gold uppercase tracking-mega-widest">{currentT.inventory}</h3>
            <p className="text-[12px] text-white/30 font-light italic tracking-wide">{currentT.manifest}</p>
            {profile.allergies.length > 0 && (
              <div className="flex items-center gap-3 mt-6 bg-gold/[0.02] border border-gold/10 px-4 py-2 rounded-full w-fit">
                <div className="w-1.5 h-1.5 rounded-full bg-gold animate-subtle-pulse"></div>
                <p className="text-[9px] text-gold/60 font-black uppercase tracking-mega-widest">{currentT.filters}</p>
              </div>
            )}
          </header>

          <div className="flex flex-wrap gap-3 max-h-[450px] overflow-y-auto pr-4 custom-scrollbar">
            {filteredPantry.length === 0 ? (
               <p className="text-[11px] text-white/10 italic">Archive currently empty or filtered.</p>
            ) : filteredPantry.map(item => (
              <button 
                key={item} 
                onClick={() => toggleIngredient(item)}
                className={`px-6 py-4 rounded-2xl text-[10px] font-bold transition-all border ${
                  selectedIngredients.includes(item) 
                    ? 'bg-gold text-black border-gold shadow-[0_15px_35px_rgba(212,175,55,0.2)] scale-[1.04]' 
                    : 'bg-white/[0.01] border-white/5 text-white/20 hover:border-gold/20 hover:text-white/60'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
          
          <div className="pt-8">
            <button 
              onClick={handleGenerate}
              disabled={selectedIngredients.length === 0 || loading}
              className="w-full py-7 bg-white text-black rounded-[36px] font-black text-[12px] uppercase tracking-mega-widest shadow-2xl hover:bg-gold transition-all disabled:opacity-5 active:scale-95"
            >
              {loading ? <LoaderIcon className="animate-spin mx-auto scale-75" /> : currentT.synthesize}
            </button>
          </div>
        </div>

        {/* Action Center */}
        <div className="lg:col-span-8 space-y-12">
          {!loading && !recipe && (
            <div className="py-56 text-center glass rounded-[72px] border-white/5 border-dashed flex flex-col items-center justify-center space-y-12 group hover:gold-border-subtle transition-all duration-1000 bg-surface/40 shadow-inner">
              <div className="w-28 h-28 bg-gold/[0.01] border border-gold/5 rounded-full flex items-center justify-center group-hover:scale-110 transition-all duration-1000 group-hover:shadow-[0_0_50px_rgba(212,175,55,0.05)]">
                 <SparklesIcon className="w-12 h-12 text-gold/10 group-hover:text-gold/30 transition-colors" />
              </div>
              <div className="space-y-5">
                <p className="text-white/20 font-display italic text-3xl group-hover:text-white/40 transition-colors">{currentT.awaiting}</p>
                <p className="text-[10px] text-white/5 uppercase font-black tracking-mega-widest">{currentT.define}</p>
              </div>
            </div>
          )}

          {loading && (
            <div className="py-40 text-center space-y-12 glass rounded-[72px] border-gold/10 relative overflow-hidden bg-surface shadow-2xl">
              <div className="absolute inset-0 bg-gold/[0.01] animate-subtle-pulse"></div>
              <div className="w-24 h-24 border-t-2 border-gold rounded-full animate-spin mx-auto shadow-[0_0_40px_rgba(212,175,55,0.1)]"></div>
              <div className="space-y-4 relative z-10">
                <p className="text-gold text-[11px] font-black uppercase tracking-mega-widest animate-pulse">{currentT.progress}</p>
                <p className="text-white/20 text-[11px] font-light italic tracking-ultra-widest">{currentT.mapping}</p>
              </div>
            </div>
          )}

          {recipe && !loading && (
            <div className="glass rounded-[80px] overflow-hidden border-white/5 animate-in slide-in-from-bottom-20 duration-1000 shadow-[0_60px_120px_rgba(0,0,0,0.8)] bg-surface">
              <div className="aspect-[21/10] relative overflow-hidden">
                <img src={recipe.image} className="w-full h-full object-cover opacity-60 transition-transform duration-3000 scale-105 hover:scale-100" alt={recipe.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"></div>
                <div className="absolute bottom-16 left-20 right-20 flex justify-between items-end">
                  <div className="space-y-6">
                    <h2 className="text-7xl font-display font-bold text-white tracking-tight leading-none text-glow">{recipe.title}</h2>
                    <div className="flex gap-5">
                      <Tag icon={<ClockIcon className="w-3.5 h-3.5"/>} text={`${recipe.prepTime} min`} />
                      <Tag icon={<FireIcon className="w-3.5 h-3.5"/>} text={`${recipe.nutrition.calories} kcal`} />
                      <Tag icon={<UserIcon className="w-3.5 h-3.5"/>} text={recipe.difficulty} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-20 grid grid-cols-1 xl:grid-cols-2 gap-24">
                <div className="space-y-16">
                  <header className="border-b border-white/5 pb-10">
                    <h3 className="text-[11px] font-black text-gold uppercase tracking-mega-widest">{currentT.elemental}</h3>
                  </header>
                  <ul className="space-y-6">
                    {recipe.ingredients.map((ing, i) => (
                      <li key={i} className="flex justify-between items-center text-sm group">
                        <span className="text-white/30 group-hover:text-white/70 transition-colors font-light tracking-wide italic">{ing.name}</span>
                        <span className="text-gold font-bold bg-gold/[0.02] px-5 py-2 rounded-2xl border border-gold/10 text-[10px] tabular-nums">{ing.amount} {ing.unit}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <div className="p-12 glass rounded-[48px] gold-border-subtle grid grid-cols-3 gap-8 text-center bg-gold/[0.005]">
                    <MacroItem label="P" value={recipe.nutrition.protein} />
                    <MacroItem label="C" value={recipe.nutrition.carbs} />
                    <MacroItem label="L" value={recipe.nutrition.fats} />
                  </div>
                </div>

                <div className="space-y-16">
                  <header className="border-b border-white/5 pb-10">
                    <h3 className="text-[11px] font-black text-gold uppercase tracking-mega-widest">{currentT.orchestration}</h3>
                  </header>
                  <div className="space-y-12 max-h-[600px] overflow-y-auto pr-8 custom-scrollbar">
                    {recipe.steps.map((step, i) => (
                      <div key={i} className={`flex gap-12 transition-all duration-1000 ${activeStep === i ? 'opacity-100' : 'opacity-10 scale-[0.98] cursor-pointer hover:opacity-30'}`} onClick={() => setActiveStep(i)}>
                        <div className="text-5xl font-display font-bold text-gold/10 italic shrink-0 tabular-nums">{String(i + 1).padStart(2, '0')}</div>
                        <p className="text-[15px] leading-relaxed text-white/50 font-light italic pt-2">{step.instruction}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Tag = ({ icon, text }: { icon: any, text: string }) => (
  <span className="flex items-center gap-3.5 bg-black/60 border border-white/5 px-6 py-3 rounded-full backdrop-blur-3xl text-[10px] font-black uppercase tracking-mega-widest text-gold/80 shadow-2xl">
    {icon} {text}
  </span>
);

const MacroItem = ({ label, value }: { label: string, value: number }) => (
  <div>
    <p className="text-[9px] text-white/20 font-black uppercase mb-3 tracking-mega-widest">{label}</p>
    <p className="text-3xl font-display font-bold text-white tabular-nums">{value}<span className="text-[10px] font-sans text-gold/30 ml-1.5">g</span></p>
  </div>
);

export default RecipeGenerator;
